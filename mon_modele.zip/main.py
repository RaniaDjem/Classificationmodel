from fastapi import FastAPI
from google.cloud import storage
from tensorflow.keras.models import load_model
import os

app = FastAPI()
model = None

@app.on_event("startup")
async def load_model_on_startup():
    global model
    bucket_name = 'bucket-de-machinelearning'
    model_path = 'mon_modele.h5'  # Mettez à jour avec le chemin exact de votre modèle dans le bucket
    local_model_path = '/tmp/model.h5'

    # Initialize the GCS client
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(model_path)

    # Download the model to a local temporary file
    blob.download_to_filename(local_model_path)

    # Load the model
    model = load_model(local_model_path)
    print("Model loaded successfully.")

@app.get("/")
async def root():
    if model:
        return {"message": "Model loaded successfully."}
    else:
        return {"message": "Model not loaded."}

# Define the main function for the functions-framework
def main(request):
    return app(request)
